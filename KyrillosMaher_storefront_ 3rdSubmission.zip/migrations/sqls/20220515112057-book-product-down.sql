-- DROP TABLE if exists book_product cascade;

DROP TABLE book_product;