-- DROP TABLE if exists orders cascade;
DROP TABLE orders;