-- DROP TABLE if exists users cascade;
DROP TABLE users ;