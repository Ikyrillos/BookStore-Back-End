-- DROP TABLE if exists order_books cascade;
DROP TABLE order_books;